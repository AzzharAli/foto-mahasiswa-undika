<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Web</title>
</head>
<body>

<h4> WEB ini saya buat karena saya sedang gabut dan pengen belajar bahasa PHP </h4>
<br>
<p>Jika ada pihak yang kurang berkenan bisa langsung hubungi admin untuk menghapus web ini terima kasih</p><br><br>

<a> Pokok e aku nggwe web iki kongkonan e Febri </a>
    
</body>
</html>